"""Modèle de Scoring IA - Hunter Agency"""
from typing import Dict, Any
from src.ai.features import ProfileFeatures
from src.utils import get_logger

logger = get_logger(__name__)

class AIProfileScorer:
    """Scoreur IA principal pour les profils"""
    
    def __init__(self):
        self.features_extractor = ProfileFeatures()
        self.is_ready = True
        self.version = "2.0"
        
        # Poids des features pour le scoring
        self.feature_weights = {
            'has_email': 25,
            'email_quality': 15,
            'has_phone': 20,
            'phone_quality': 10,
            'has_name': 10,
            'social_count': 10,
            'completeness_score': 10
        }
    
    def score_profile(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """Scorer un profil complet"""
        logger.info(f"🎯 Scoring du profil: {profile_data.get('name', 'Sans nom')}")
        
        try:
            # Extraire toutes les features
            features = self.features_extractor.extract_all_features(profile_data)
            
            # Calculer le score global
            overall_score = self._calculate_overall_score(features)
            
            # Déterminer le grade
            grade = self._determine_grade(overall_score)
            
            # Prédire la conversion
            conversion_prob = self._predict_conversion(features, overall_score)
            
            # Générer les recommandations
            recommendations = self._generate_recommendations(features, overall_score)
            
            result = {
                'overall_score': round(overall_score, 1),
                'grade': grade,
                'conversion_probability': round(conversion_prob, 3),
                'features_count': len(features),
                'recommendations': recommendations,
                'confidence': self._calculate_confidence(features),
                'timestamp': 'now',
                'version': self.version
            }
            
            logger.info(f"✅ Score calculé: {overall_score:.1f}/100 ({grade})")
            return result
            
        except Exception as e:
            logger.error(f"❌ Erreur scoring: {e}")
            return {
                'overall_score': 0,
                'grade': 'ERROR',
                'error': str(e)
            }
    
    def _calculate_overall_score(self, features: Dict[str, float]) -> float:
        """Calcul du score global basé sur les features"""
        score = 0.0
        
        for feature_name, weight in self.feature_weights.items():
            if feature_name in features:
                score += features[feature_name] * weight
        
        return min(score, 100.0)
    
    def _determine_grade(self, score: float) -> str:
        """Déterminer le grade du lead"""
        if score >= 85:
            return "HOT_LEAD"
        elif score >= 70:
            return "WARM_LEAD"
        elif score >= 50:
            return "COLD_LEAD"
        else:
            return "POOR_LEAD"
    
    def _predict_conversion(self, features: Dict[str, float], score: float) -> float:
        """Prédire la probabilité de conversion"""
        base_prob = score / 100.0
        
        # Bonus pour contacts multiples
        if features.get('has_email', 0) and features.get('has_phone', 0):
            base_prob *= 1.2
        
        # Bonus pour réseaux sociaux
        if features.get('social_count', 0) >= 2:
            base_prob *= 1.1
        
        return min(base_prob, 1.0)
    
    def _generate_recommendations(self, features: Dict[str, float], score: float) -> list:
        """Générer des recommandations d'action"""
        recommendations = []
        
        if score >= 80:
            recommendations.append("📞 CONTACTER IMMÉDIATEMENT - Lead chaud")
        elif score >= 60:
            recommendations.append("⚡ Contacter rapidement - Lead prometteur")
        
        if not features.get('has_email', 0):
            recommendations.append("📧 Rechercher l'email via réseaux sociaux")
        
        if not features.get('has_phone', 0):
            recommendations.append("�� Obtenir le numéro de téléphone")
        
        if features.get('social_count', 0) == 0:
            recommendations.append("🔍 Rechercher présence sur réseaux sociaux")
        
        if features.get('completeness_score', 0) < 0.5:
            recommendations.append("📝 Enrichir les données du profil")
        
        return recommendations
    
    def _calculate_confidence(self, features: Dict[str, float]) -> float:
        """Calculer le niveau de confiance du scoring"""
        # Plus on a de données, plus on est confiant
        data_completeness = features.get('completeness_score', 0)
        contact_quality = (features.get('email_quality', 0) + features.get('phone_quality', 0)) / 2
        
        confidence = (data_completeness * 0.6) + (contact_quality * 0.4)
        return round(confidence, 3)
    
    def get_status(self) -> Dict[str, Any]:
        """Statut du modèle IA"""
        return {
            'status': 'ready' if self.is_ready else 'loading',
            'version': self.version,
            'features_available': len(self.feature_weights),
            'model_type': 'rule_based_ai',
            'capabilities': [
                'profile_scoring',
                'lead_grading', 
                'conversion_prediction',
                'recommendations_generation'
            ]
        }
