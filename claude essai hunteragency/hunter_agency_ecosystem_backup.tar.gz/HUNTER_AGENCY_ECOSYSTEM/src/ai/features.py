"""Feature Engineering - Hunter Agency IA"""
import re
from typing import Dict, Any

class ProfileFeatures:
    """Extraction des caractéristiques d'un profil"""
    
    def extract_all_features(self, profile: Dict[str, Any]) -> Dict[str, float]:
        """Extraire toutes les features d'un profil"""
        features = {}
        
        # Features de base
        features.update(self._basic_features(profile))
        
        # Features de contact
        features.update(self._contact_features(profile))
        
        # Features sociales
        features.update(self._social_features(profile))
        
        # Features de qualité
        features.update(self._quality_features(profile))
        
        return features
    
    def _basic_features(self, profile: Dict) -> Dict[str, float]:
        """Features de base"""
        return {
            'has_name': 1.0 if profile.get('name') else 0.0,
            'name_length': float(len(profile.get('name', ''))),
            'has_age': 1.0 if profile.get('age') else 0.0,
            'age_value': float(profile.get('age', 0)),
            'has_location': 1.0 if profile.get('location') else 0.0
        }
    
    def _contact_features(self, profile: Dict) -> Dict[str, float]:
        """Features de contact"""
        email = profile.get('email', '')
        phone = profile.get('phone', '')
        
        return {
            'has_email': 1.0 if email else 0.0,
            'email_quality': self._score_email(email),
            'has_phone': 1.0 if phone else 0.0,
            'phone_quality': self._score_phone(phone),
            'contact_completeness': self._contact_score(email, phone)
        }
    
    def _social_features(self, profile: Dict) -> Dict[str, float]:
        """Features des réseaux sociaux"""
        social_platforms = ['instagram', 'twitter', 'onlyfans', 'snapchat']
        social_count = sum(1 for platform in social_platforms if profile.get(f'{platform}_url'))
        
        return {
            'social_count': float(social_count),
            'social_ratio': float(social_count / len(social_platforms)),
            'has_instagram': 1.0 if profile.get('instagram_url') else 0.0,
            'has_twitter': 1.0 if profile.get('twitter_url') else 0.0,
            'has_onlyfans': 1.0 if profile.get('onlyfans_url') else 0.0
        }
    
    def _quality_features(self, profile: Dict) -> Dict[str, float]:
        """Features de qualité globale"""
        desc = profile.get('description', '')
        
        return {
            'has_description': 1.0 if desc else 0.0,
            'description_length': float(len(desc)),
            'description_words': float(len(desc.split()) if desc else 0),
            'completeness_score': self._completeness_score(profile)
        }
    
    def _score_email(self, email: str) -> float:
        """Scorer la qualité de l'email"""
        if not email:
            return 0.0
        
        score = 0.0
        
        # Format valide
        if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            score += 0.6
        
        # Domaines populaires
        if any(domain in email.lower() for domain in ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']):
            score += 0.3
        
        # Longueur raisonnable
        if 5 <= len(email) <= 50:
            score += 0.1
        
        return min(score, 1.0)
    
    def _score_phone(self, phone: str) -> float:
        """Scorer la qualité du téléphone"""
        if not phone:
            return 0.0
        
        clean_phone = re.sub(r'[^\d+]', '', phone)
        
        score = 0.0
        
        # Longueur appropriée
        if 10 <= len(clean_phone) <= 15:
            score += 0.5
        
        # Format international
        if clean_phone.startswith('+'):
            score += 0.3
        
        # Pas de répétitions excessives
        if not re.search(r'(\d)\1{4,}', clean_phone):
            score += 0.2
        
        return min(score, 1.0)
    
    def _contact_score(self, email: str, phone: str) -> float:
        """Score de complétude des contacts"""
        score = 0.0
        if email: score += 0.5
        if phone: score += 0.5
        return score
    
    def _completeness_score(self, profile: Dict) -> float:
        """Score de complétude global du profil"""
        required_fields = ['name', 'email', 'phone', 'age', 'location']
        completed = sum(1 for field in required_fields if profile.get(field))
        return float(completed / len(required_fields))
