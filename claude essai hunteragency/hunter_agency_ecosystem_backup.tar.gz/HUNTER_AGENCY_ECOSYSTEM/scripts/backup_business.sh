#!/bin/bash
echo "💾 Backup en cours..."
mkdir -p backups
echo "✅ Backup terminé"
